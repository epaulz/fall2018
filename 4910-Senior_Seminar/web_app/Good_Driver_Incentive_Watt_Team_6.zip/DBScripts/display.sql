select *
from ACCOUNT;
select *
from SPONSOR;
select *
from ADMINS;
select *
from BUYS;
select *
from WORKS_FOR
into OUTFILE 'output.csv';