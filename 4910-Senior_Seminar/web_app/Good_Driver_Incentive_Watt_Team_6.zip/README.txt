Adding this readme file to test that I successfully push it to our project, but it'd be 
good practice to update it and include it in our repository when we submit it at the end of the semester!