cat ls-redaction.txt | python src/extract-years.py > years.txt
