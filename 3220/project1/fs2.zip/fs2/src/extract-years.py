# File listing redaction
# https://stackoverflow.com/questions/5899497/checking-file-extension
# https://stackoverflow.com/questions/1450393/how-do-you-read-from-stdin-in-python

import os
import sys
import re

for line in sys.stdin:
  cleanline = line.rstrip()
  fields    = cleanline.split()
  if len(fields) <> 9:
    continue # ignore for present purposes; symlinks, etc.

  year = fields[7]
  if (year.find(':') >= 0):
    year=2015

  print year

### end ###
