cat ../*ls2 | python src/ls-redaction.py > ls-redaction.txt 
