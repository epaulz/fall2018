sort -rn years.txt | uniq -c | sort -rn > years2.txt
