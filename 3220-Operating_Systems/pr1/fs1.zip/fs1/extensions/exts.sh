cat * | sort | uniq -c | sort -rn | less > exts.txt
