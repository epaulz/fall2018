for i in t*
do
 cat $i | python redaction/*py > redaction/$i
done

