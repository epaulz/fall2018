# File listing redaction

import os
import sys
import re

for line in sys.stdin:
  year = line[44:49] # extract up to the filename
  print year

### end ###
