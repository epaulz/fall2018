# File listing redaction

while (<>) {
  firstPart  = substr($_, 0, 49) # extract up to the filename
  secondPart = substr($_, 49)    # extract filename and beyond

  if ($secondPart ~= '/[a-zA-Z0-9]\.[a-zA-Z0-9]*$/') { # seems to end with traditional extension pattern
  if (postfix ~= '/\.[a-zA-Z0-9]*$/') { # seems to end with traditional extension pattern
    

}


### end ###
