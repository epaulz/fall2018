for i in t*
do
 cat $i | python src/extract-extensions.py > extensions/$i
done

