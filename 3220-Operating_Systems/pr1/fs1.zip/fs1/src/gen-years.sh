cat t* | awk '{print substr($0,44,5)}' | sort | uniq -c | sort -rn | head
