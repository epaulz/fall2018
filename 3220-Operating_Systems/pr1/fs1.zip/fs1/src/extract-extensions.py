# File listing redaction
# https://stackoverflow.com/questions/5899497/checking-file-extension
# https://stackoverflow.com/questions/1450393/how-do-you-read-from-stdin-in-python

import os
import sys
import re

for line in sys.stdin:
  preFn   = line[0:49] # extract up to the filename
  rawFn   = line[49:]  # extract filename 
  cleanFn = rawFn.rstrip()
  
  (fn, extension) = os.path.splitext(cleanFn)
  print extension

### end ###
